const pool = require('../config/db');
const { successResponse, errorResponse } = require('../utils/apiResponse');

// Get all users
const getAllUsers = async (req, res, next) => {
  try {
    const [users] = await pool.execute(
      'SELECT u.id, u.full_name, u.email, u.phone, u.status, r.name as role_name, u.created_at FROM users u JOIN roles r ON u.role_id = r.id ORDER BY u.id DESC'
    );
    return successResponse(res, 200, 'Users fetched successfully', users);
  } catch (error) {
    next(error);
  }
};

// Get single user by ID
const getUserById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [users] = await pool.execute(
      'SELECT u.id, u.full_name, u.email, u.phone, u.status, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?',
      [id]
    );

    if (users.length === 0) {
      return errorResponse(res, 404, 'User not found.');
    }

    return successResponse(res, 200, 'User details fetched', users[0]);
  } catch (error) {
    next(error);
  }
};

// Update user details or status
const updateUser = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { full_name, phone, role_id, status } = req.body;

    await pool.execute(
      'UPDATE users SET full_name = COALESCE(?, full_name), phone = COALESCE(?, phone), role_id = COALESCE(?, role_id), status = COALESCE(?, status) WHERE id = ?',
      [full_name, phone, role_id, status, id]
    );

    return successResponse(res, 200, 'User updated successfully');
  } catch (error) {
    next(error);
  }
};

module.exports = { getAllUsers, getUserById, updateUser };