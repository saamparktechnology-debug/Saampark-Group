const pool = require('../config/db');
const { hashPassword, comparePassword } = require('../utils/passwordHash');
const { generateToken } = require('../utils/generateToken');
const { successResponse, errorResponse } = require('../utils/apiResponse');

// Register a new user / employee
const register = async (req, res, next) => {
  try {
    const { full_name, email, password, phone, role_id } = req.body;

    // Check if user already exists
    const [existingUsers] = await pool.execute('SELECT id FROM users WHERE email = ?', [email]);
    if (existingUsers.length > 0) {
      return errorResponse(res, 400, 'User with this email already exists.');
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Insert user into database
    const [result] = await pool.execute(
      'INSERT INTO users (role_id, full_name, email, password_hash, phone) VALUES (?, ?, ?, ?, ?)',
      [role_id || 3, full_name, email, hashedPassword, phone || null]
    );

    const userId = result.insertId;
    const token = generateToken({ id: userId, email, role_id: role_id || 3 });

    return successResponse(res, 201, 'User registered successfully', {
      user: { id: userId, full_name, email, role_id: role_id || 3 },
      token
    });
  } catch (error) {
    next(error);
  }
};

// Login user
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    const [users] = await pool.execute(
      'SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.email = ?',
      [email]
    );

    if (users.length === 0) {
      return errorResponse(res, 401, 'Invalid email or password.');
    }

    const user = users[0];

    if (user.status !== 'active') {
      return errorResponse(res, 403, 'Your account is deactivated. Contact admin.');
    }

    const isMatch = await comparePassword(password, user.password_hash);
    if (!isMatch) {
      return errorResponse(res, 401, 'Invalid email or password.');
    }

    const token = generateToken({ id: user.id, email: user.email, role_id: user.role_id });

    delete user.password_hash;

    return successResponse(res, 200, 'Login successful', { user, token });
  } catch (error) {
    next(error);
  }
};

// Get profile of logged-in user
const getProfile = async (req, res, next) => {
  try {
    const [users] = await pool.execute(
      'SELECT u.id, u.full_name, u.email, u.phone, u.status, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?',
      [req.user.id]
    );

    if (users.length === 0) {
      return errorResponse(res, 404, 'User profile not found.');
    }

    return successResponse(res, 200, 'User profile retrieved', users[0]);
  } catch (error) {
    next(error);
  }
};

module.exports = { register, login, getProfile };