const express = require('express');
const router = express.Router();
const { getAllUsers, getUserById, updateUser } = require('../controllers/userController');
const authenticate = require('../middlewares/authMiddleware');
const authorizeRoles = require('../middlewares/roleMiddleware');

// All routes require authentication
router.use(authenticate);

// List users (Admin & Sales Manager)
router.get('/', authorizeRoles(1, 2), getAllUsers);

// Get single user
router.get('/:id', getUserById);

// Update user details (Admin only)
router.put('/:id', authorizeRoles(1), updateUser);

module.exports = router;