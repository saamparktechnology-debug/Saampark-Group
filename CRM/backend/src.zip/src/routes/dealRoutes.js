const express = require('express');
const router = express.Router();
const { createDeal, getAllDeals, updateDealStage } = require('../controllers/dealController');
const authenticate = require('../middlewares/authMiddleware');

router.use(authenticate);

router.post('/', createDeal);
router.get('/', getAllDeals);
router.patch('/:id/stage', updateDealStage);

module.exports = router;