const express = require('express');
const router = express.Router();
const { createTicket, getAllTickets, addTicketComment } = require('../controllers/ticketController');
const authenticate = require('../middlewares/authMiddleware');

router.use(authenticate);

router.post('/', createTicket);
router.get('/', getAllTickets);
router.post('/:id/comments', addTicketComment);

module.exports = router;