const express = require('express');
const router = express.Router();
const { createCampaign, getAllCampaigns } = require('../controllers/campaignController');
const authenticate = require('../middlewares/authMiddleware');

router.use(authenticate);

router.post('/', createCampaign);
router.get('/', getAllCampaigns);

module.exports = router;