const express = require('express');
const router = express.Router();
const { 
  createLead, 
  getAllLeads, 
  getLeadById, 
  updateLead, 
  convertLeadToCustomer 
} = require('../controllers/leadController');
const authenticate = require('../middlewares/authMiddleware');

router.use(authenticate);

router.post('/', createLead);
router.get('/', getAllLeads);
router.get('/:id', getLeadById);
router.put('/:id', updateLead);
router.post('/:id/convert', convertLeadToCustomer);

module.exports = router;