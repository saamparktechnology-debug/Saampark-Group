const express = require('express');
const router = express.Router();
const { 
  getPackages, 
  subscribeCustomer, 
  getSubscriptions, 
  changeStatus 
} = require('../controllers/subscriptionController');
const authenticate = require('../middlewares/authMiddleware');

router.use(authenticate);

router.get('/packages', getPackages);          // GET /api/v1/subscriptions/packages
router.post('/subscribe', subscribeCustomer);  // POST /api/v1/subscriptions/subscribe
router.get('/', getSubscriptions);              // GET /api/v1/subscriptions
router.patch('/:id/status', changeStatus);      // PATCH /api/v1/subscriptions/:id/status

module.exports = router;