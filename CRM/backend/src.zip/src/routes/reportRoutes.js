const express = require('express');
const router = express.Router();
const { getDashboardOverview } = require('../controllers/reportController');
const authenticate = require('../middlewares/authMiddleware');

router.use(authenticate);

router.get('/dashboard', getDashboardOverview);

module.exports = router;