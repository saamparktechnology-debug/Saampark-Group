const express = require('express');
const router = express.Router();
const { createTask, getAllTasks, updateTaskStatus } = require('../controllers/taskController');
const authenticate = require('../middlewares/authMiddleware');

router.use(authenticate);

router.post('/', createTask);
router.get('/', getAllTasks);
router.patch('/:id/status', updateTaskStatus);

module.exports = router;