const { verifyToken } = require('../utils/generateToken');
const { errorResponse } = require('../utils/apiResponse');

/**
 * Middleware to authenticate requests using JWT
 */
const authenticate = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return errorResponse(res, 401, 'Authentication required. Token missing or invalid format.');
    }

    const token = authHeader.split(' ');
    const decoded = verifyToken(token);

    // Attach user information from decoded JWT to the request object
    req.user = decoded;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return errorResponse(res, 401, 'Token has expired. Please log in again.');
    }
    return errorResponse(res, 401, 'Invalid authentication token.');
  }
};

module.exports = authenticate;